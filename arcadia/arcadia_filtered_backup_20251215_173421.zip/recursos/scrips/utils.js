window.Arcadia = window.Arcadia || {};
(function (A) {
  'use strict';
  const Utils = {
    safeNumber(val){
      let s = String(val ?? '').trim();
      if (!s) return 0;

      // Limpia moneda/espacios y caracteres raros
      s = s
        .replace(/\s+/g, '')
        .replace(/[$COPcop]/g, '')
        .replace(/[^\d.,\-]/g, '');

      const hasDot = s.includes('.');
      const hasComma = s.includes(',');

      // es-CO típico: 1.234.567,89
      if (hasDot && hasComma) {
        s = s.replace(/\./g, '').replace(/,/g, '.');
      } else if (hasDot && !hasComma) {
        // Si hay más de un punto, son miles (1.234.567)
        const dots = (s.match(/\./g) || []).length;
        if (dots > 1) s = s.replace(/\./g, '');
      } else if (hasComma && !hasDot) {
        // 1234,56 => decimal
        s = s.replace(/,/g, '.');
      }

      const n = parseFloat(s);
      return isFinite(n) ? n : 0;
    },

    formatCurrency(num){
      return new Intl.NumberFormat('es-CO',{
        style:'currency', currency:'COP',
        minimumFractionDigits:0, maximumFractionDigits:0
      }).format(Math.round(num));
    },

    formatNumber(num){
      return new Intl.NumberFormat('es-CO',{
        minimumFractionDigits:0, maximumFractionDigits:0
      }).format(Math.round(num));
    },

    // ✅ Fecha ISO LOCAL (evita UTC/toISOString que puede correrte el día en Colombia)
    nowDateISO(){
      const d = new Date();
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return `${y}-${m}-${day}`;
    },

    // ✅ Suma días usando mediodía local para evitar saltos por zona horaria
    dateAddDays(iso, days){
      const d = new Date(iso + 'T12:00:00');
      d.setDate(d.getDate()+days);
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return `${y}-${m}-${day}`;
    },

    yesterdayISO(){ return Utils.dateAddDays(Utils.nowDateISO(), -1); },

    uuidv4(){
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
        const r = Math.random()*16|0, v = c==='x' ? r : (r&0x3|0x8);
        return v.toString(16);
      });
    },

    escapeHtml(s){
      return String(s == null ? '' : s)
        .replaceAll('&','&amp;')
        .replaceAll('<','&lt;')
        .replaceAll('>','&gt;')
        .replaceAll('"','&quot;');
    },

    getDatesInRange(startDate, endDate) {
      const date = new Date(startDate + 'T12:00:00');
      const end = new Date(endDate + 'T12:00:00');
      const dates = [];

      const fmt = (d) => {
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${y}-${m}-${day}`;
      };

      while (date <= end) {
        dates.push(fmt(date));
        date.setDate(date.getDate() + 1);
      }
      return dates;
    },

    /* =========================================================
       ✅ CARGA DINÁMICA DE SCRIPTS
       ========================================================= */
    loadScript(src, opts = {}){
      const { test, timeoutMs = 12000 } = opts;
      return new Promise((resolve, reject) => {
        let done = false;
        let timer = null;

        const finish = (ok, err) => {
          if (done) return;
          done = true;
          if (timer) clearTimeout(timer);
          ok ? resolve(true) : reject(err);
        };

        try{
          if (typeof test === 'function' && test()) {
            finish(true);
            return;
          }
        }catch(_){}

        const already = Array.from(document.scripts || []).some(s => s && s.src && s.src === src);
        if (already) {
          try{
            if (!test || test()) finish(true);
            else finish(false, new Error('Script existente pero test no pasó: ' + src));
          }catch(e){
            finish(false, e);
          }
          return;
        }

        const s = document.createElement('script');
        s.src = src;
        s.async = true;

        s.onload = () => {
          try{
            if (typeof test === 'function') {
              if (test()) finish(true);
              else finish(false, new Error('Script cargado pero test no pasó: ' + src));
            } else {
              finish(true);
            }
          }catch(e){
            finish(false, e);
          }
        };

        s.onerror = () => finish(false, new Error('No se pudo cargar el script: ' + src));

        document.head.appendChild(s);

        if (timeoutMs) {
          timer = setTimeout(() => {
            try{
              if (typeof test === 'function' && test()) finish(true);
              else finish(false, new Error('Tiempo de espera al cargar: ' + src));
            }catch(e){
              finish(false, e);
            }
          }, timeoutMs);
        }
      });
    }
  };

  A.Utils = Utils;
})(window.Arcadia);

